"use client";

import { createClient } from "@supabase/supabase-js";

export function getRoomName() {
  return process.env.NEXT_PUBLIC_CUE_ROOM_NAME || "hotdrive";
}

export function createSupabaseBrowserClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !key) return null;

  return createClient(url, key, {
    realtime: {
      params: {
        eventsPerSecond: 10
      }
    }
  });
}
